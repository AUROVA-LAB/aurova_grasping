#!/usr/bin/env python


# fifth version of the interface
# here I merge the third and fourth version: class + communications 
# with ros + digit sensor reading + model predictions

from Tkinter import *
from PIL import ImageTk, Image
import ttk
import cv2
import numpy as np
import zmq
import time
import traceback
import logging
import argparse
import tensorflow as tf 
from digit_interface.digit import Digit
from digit_interface.digit_handler import DigitHandler
from tensorflow.keras.models import model_from_json
import pprint


parser = argparse.ArgumentParser()

parser.add_argument('-m', '--model', type=str, help='model to predict')
parser.add_argument('-w', '--weights', type=str, help='weights to predict')
args = parser.parse_args()

filename_model = args.model
filename_weights = args.weights

json_file = open(filename_model)
loaded_model_json = json_file.read()
json_file.close()
model = model_from_json(loaded_model_json)
model.load_weights(filename_weights)


digit50 = cv2.VideoCapture(3)
digit55 = cv2.VideoCapture(4)


class Interface():
    "This class creates the COMANNDIA interface"

    # constructor
    def __init__(self, title="Window", size_window=(1200, 1500), size_images=[(300, 300), (300,300)], button_quit_text="Exit", button_start_text="Start", button_bc_text="Break communication"):
        self.title = title
        self.w_window = size_window[0]
        self.h_window = size_window[1]
        self.size_images = size_images
        self.__root = Tk()
        self.__main_frame = Frame(self.__root)
        self.__my_canvas = Canvas(self.__main_frame)
        self.__my_scrollbar = ttk.Scrollbar(self.__main_frame, orient=VERTICAL, command=self.__my_canvas.yview)
        self.__second_frame = Frame(self.__my_canvas)
        self.__root.geometry(str(self.w_window) + "x" + str(self.h_window))
        self.__button_break_comms = Button(self.__second_frame, text=button_bc_text, command=self.break_communication)
        self.__button_quit = Button(self.__second_frame, text=button_quit_text, command=self.__second_frame.quit)
        self.__button_start = Button(self.__second_frame, text=button_start_text, command=self.start_visualization)   
        self.__labels = []
        self.__img_loc_confirm = False
        self.__PORT = "5556"
        self.__context_socket = zmq.Context()
        self.__server = self.__context_socket.socket(zmq.REP)
        self.__server.bind("tcp://*:%s" % self.__PORT)
        self.__action = 0
        self.__img_count = 0
        self.__frames_digit50 = []
        self.__frames_digit55 = []
        

    # getters

    # get tk object.
    @property
    def get_root(self):
        return self.__root


    # get main frame object
    @property
    def get_main_frame(self):
        return self.__main_frame


    # get canvas object
    @property
    def get_canvas(self):
        return self.__my_canvas


    # get scrollbar object
    @property
    def get_scrollbar(self):
        return self.__my_scrollbar


    # get final frame object
    @property
    def get_second_frame(self):
        return self.__second_frame


    # get quit button (close interface) object    
    @property
    def get_button_quit(self):
        return self.__button_quit


    # get start button (start program) object
    @property
    def get_button_start(self):
        return self.__button_start
    

    # get break communications button object
    @property
    def get_button_bc(self):
        return self.__button_break_comms


    # get vector of labels of the images. This labels are used 
    # in order to show and update the images in the interface.
    @property
    def get_labels_vector(self):
        return self.__labels


    # this function returns the variable that informs if 
    # the images have been placed. When the images are placed
    # we can start updating them.
    @property
    def get_img_loc_confirm(self):
        return self.__img_loc_confirm


    # setter function
    # this function change the value of img_loc_confirm in order
    # to inform that the images have been placed.
    @get_img_loc_confirm.setter
    def set_img_loc_confirm(self, value):
        self.__img_loc_confirm = value


    # get the context object of the socket
    @property
    def get_context_socket(self):
        return self.__context_socket


    # get the server object
    @property
    def get_server(self):
        return self.__server

    
    # get the value that represents the action we are going
    # to send to the gripper
    @property
    def get_action(self):
        return self.__action

    # get the img count of digit sensor. we need 4 images to predict 
    # with our cnn model.
    @property
    def get_img_count(self):
        return self.__img_count


    # list where we save digit frames to feed the cnn later.
    @property
    def get_frames_digit50(self):
        return self.__frames_digit50


    @property
    def get_frames_digit55(self):
        return self.__frames_digit55


    # we save here the images from digit sensor.
    @get_frames_digit50.setter
    def set_frames_digit50(self, img):
        self.__frames_digit50.append(img)


    # we save here the images from digit sensor.
    @get_frames_digit55.setter
    def set_frames_digit55(self, img):
        self.__frames_digit55.append(img)


    # here we empty the list with digit images that 
    # we use to feed the cnn
    @get_frames_digit50.setter
    def set_empty_frames_digit50(self, value):
        self.__frames_digit50 = value

    
    @get_frames_digit55.setter
    def set_empty_frames_digit55(self, value):
        self.__frames_digit55 = value        


    # setter function
    # set the action to the gripper
    @get_action.setter
    def set_action(self, value):
        self.__action = value

    # this function increases a counter that counts 
    # the current number of image saved from digit sensor. 
    # We need this counter because we save four images to feed 
    # the neural network.
    @get_img_count.setter
    def set_img_count(self, value):
        self.__img_count = self.__img_count + 1
    

    # this function creates the main frame of the interface
    def create_main_frame(self, fill, expand):
        self.get_main_frame.pack(fill=fill, expand=expand)

    
    # this function creates the canvas that let us to us the
    # scrollbar
    def create_canvas(self, side, fill ,expand):
        self.get_canvas.pack(side=side, fill=fill, expand=expand)


    # this function creates the scrollbar
    def create_scrollbar(self, sizd, fill):
        self.get_scrollbar.pack(side=RIGHT, fill=Y)
    
    
    # this function configures the scrollbar in the canvas
    def configure_canvas_for_scrollbar(self, scrollregion="all"):
        self.get_canvas.configure(yscrollcommand=self.get_scrollbar.set)
        self.get_canvas.bind('<Configure>', lambda e: self.get_canvas.configure(
                            scrollregion = self.get_canvas.bbox(scrollregion)))


    # this function creates a final window with everything (frames, canvas, scrollbar)
    def create_final_window(self, pos, anchor):
        self.get_canvas.create_window(pos, window=self.get_second_frame, anchor=anchor)


    # this functions shows the interface
    def visualize_interface(self):
        self.get_root.mainloop()


    # this function places the "close interface" button in the interface
    def exit_button(self, column=0, row=0):
        self.get_button_quit.grid(column=column, row=row)


    # this function places the "break communication" button in the interface
    def bc_button(self, column=0, row=10):
        self.get_button_bc.grid(column=column, row=row)


    # this function stops the communications between ros and the interface, 
    # and closes both of them.
    def break_communication(self):
        self.set_action = 5
        print("Waiting before closing...")
        data = self.get_server.recv_pyobj()
        print("Sending client to sleep...")
        self.get_server.send_pyobj(self.get_action, protocol=0)
        print("Closing...")
        self.get_server.close()
        self.get_context_socket.term()
        self.get_second_frame.quit()


    # this function places the "start program" button in the interface
    def start_button(self, column=0, row=5):
        self.get_button_start.grid(column=column, row=row)


    # this function is the most important
    # here is where everything is done, communications, read the images
    # from the sensors, process the images, send the action to the gripper (not yet!)
    def start_visualization(self):
        
        #variable used to read if ros is sending something or not
        data = None
        visualize = False
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))

        # asynchronous communication 
        # here we're trying to read if we have to get images from 
        # the sensors or not. The communications is asynchronous because 
        # the synchronous mode blocks the interface and the buttons don't work.
        try:
            print("Receiving...")
            data = self.get_server.recv_pyobj(flags=zmq.NOBLOCK)
        except zmq.ZMQError as e:
            if e.errno == zmq.EAGAIN:
                pass
            else:
                traceback.print_exc()

        # here is when we have to get the images and run our system
        if data is not None:
            # time.sleep(5)
            
            frame55 = digit55.read()
            frame50 = digit50.read()

            name_imgs = ["Sensor 1", "Image processing", "Sensor 2", "Image processing"]

            frame50_gray = cv2.cvtColor(frame50, cv2.COLOR_BGR2GRAY)
            frame55_gray = cv2.cvtColor(frame55, cv2.COLOR_BGR2GRAY)
            
            if self.get_img_count % 2 == 0:
                print("creating empty frames...")
                self.set_empty_frames_digit50 = []
                self.set_empty_frames_digit55 = []
            
            self.set_frames_digit50 = frame50_gray
            self.set_frames_digit55 = frame55_gray

            self.set_img_count = 1

            if len(self.get_frames_digit50) == 2:

                img0_50 = (self.get_frames_digit50)[0]
                img1_50 = (self.get_frames_digit50)[1]
                                
                img0_55 = (self.get_frames_digit55)[0]
                img1_55 = (self.get_frames_digit55)[1]
                
                R10_50 = img1_50 - img0_50
                R10_op_50 = cv2.morphologyEx(R10_50, cv2.MORPH_OPEN, kernel)   
                
                R10_55 = img1_55 - img0_55
                R10_op_55 = cv2.morphologyEx(R10_55, cv2.MORPH_OPEN, kernel)
                
                img_50 = np.asarray(R10_op_50)
                img_55 = np.asarray(R10_op_55)
                
                img_50 = np.reshape(img_50, (1, 320, 240, 1))
                img_55 = np.reshape(img_55, (1, 320, 240, 1))

                img_50 = img_50.astype("float32")/255
                img_55 = img_55.astype("float32")/255

                pred2_50 = model.predict(img_50)
                pred2_55 = model.predict(img_55)

                pred_class_50 = np.argmax(pred2_50)
                pred_class_55 = np.argmax(pred2_55)

                if pred_class_50 == 0:
                    text = "GRASP"
                elif pred_class_50 == 1:
                    text = "RELEASE"
                else:
                    text = "HOLD"

                frame50 = cv2.putText(frame50, text, (15, 50), cv2.FONT_HERSHEY_SIMPLEX, 
                1, (255, 0, 0), 2, cv2.LINE_AA)
                
                if pred_class_55 == 0:
                    text = "GRASP"
                elif pred_class_55 == 1:
                    text = "RELEASE"
                else:
                    text = "HOLD"

                frame55 = cv2.putText(frame55, text, (15, 50), cv2.FONT_HERSHEY_SIMPLEX, 
                1, (255, 0, 0), 2, cv2.LINE_AA)
                

                imgs = [frame50, R10_op_50, frame55, R10_op_55]


                # place, size variables of the images and the interface.
                cols = 50
                # initial position of the first image
                cols = 50
                rows = 50
                #auxiliar variables -> offsets.
                aux_cols = 0
                aux_rows = 0
                # variable that represents the actual row.
                nivel_fil = 0

                # if the images haven't been placed yet, we have to place them
                # first and in the next iterations we just update them.
                if not self.get_img_loc_confirm:
                    # for loop where we read each image, convert to pillow format
                    # and place it in the interface.
                    for i in range(len(imgs)):
                        # read the image with pillow.
                        if isinstance(imgs[i], str):
                            img = Image.open(imgs[i])
                        elif isinstance(imgs[i], np.ndarray):
                            img = cv2.cvtColor(imgs[i], cv2.COLOR_BGR2RGB)
                            img = Image.fromarray(np.uint8(img))
                        else:
                            break 
                        # resize the image.
                        resized_img = img.resize(self.size_images[i], Image.ANTIALIAS)
                        new_img = ImageTk.PhotoImage(resized_img)

                        w, h = resized_img.size
                        
                        # write the text.
                        text1 = Label(self.get_second_frame, text=name_imgs[i])
                        text1.grid(column=cols + aux_cols, row=rows + aux_rows* nivel_fil)
                        
                        # create each image.
                        label = Label(self.get_second_frame, image=new_img)
                        label.image = new_img
                        label.grid(column=cols + aux_cols + 2, row=rows + aux_rows * nivel_fil + 2)
                        self.get_labels_vector.append(label)
                        if (i+1)%2 != 0:
                            # tabulation when the images are odd.
                            aux_cols = w
                            label_tab = Label(self.get_second_frame, text="\t")
                            label_tab.grid(column=cols + aux_cols, row=rows + aux_rows* nivel_fil)
                            
                        else:
                            # end of row when the images are even.
                            nivel_fil += 2
                            aux_rows = h
                            aux_cols = 0
                            label_salto_linea = Label(self.get_second_frame, text="\n")
                            label_salto_linea.grid(column=cols, row=rows + aux_rows* nivel_fil)

                    # here we set this variable to inform that we only have to update the images from now on.
                    self.set_img_loc_confirm = True
                
                else:
                    # here is where we update the images.
                    for i in range(len(imgs)):
                        if isinstance(imgs[i], str):
                            img = Image.open(imgs[i])
                        elif isinstance(imgs[i], np.ndarray):
                            img = cv2.cvtColor(imgs[i], cv2.COLOR_BGR2RGB)
                            img = Image.fromarray(np.uint8(img))
                        else:
                            break

                        resized_img = img.resize(self.size_images[i], Image.ANTIALIAS)
                        new_img = ImageTk.PhotoImage(resized_img)

                        w, h = resized_img.size
                        self.get_labels_vector[i].configure(image=new_img)
                        self.get_labels_vector[i].image = new_img
                    

                # here is where we send the digit's prediction.
                if (pred_class_50 or pred_class_55) == 0:
                    self.set_action = 0  # grasp
                    print("sending: ", self.get_action)
                    self.get_server.send_pyobj(self.get_action, protocol=0)
                    
                elif (pred_class_50 or pred_class_55) == 1:
                    self.set_action = 1  # release
                    print("sending: ", self.get_action)
                    self.get_server.send_pyobj(self.get_action, protocol=0)
                    #self.get_second_frame.quit()
                elif (pred_class_50 and pred_class_55) == 2:
                    self.set_action = 2  # hold
                    print("sending: ", self.get_action)
                    self.get_server.send_pyobj(self.get_action, protocol=0)
                else:
                    self.set_action = 3  # wrong
                    print("sending: ", self.get_action)
                    self.get_server.send_pyobj(self.get_action, protocol=0)
            # using zmq, we can't read twice in a row if the client is sending
            # information, so we have to send something to be able to read again.
            # Then, we tell the client that we are saving images.
            else:
                self.set_action = 9  # there are not four images yet
                print("sending: ", self.get_action)
                self.get_server.send_pyobj(self.get_action, protocol=0)

        # this function is used to run start_visualization in a infinite loop.
        self.get_root.after(10, self.start_visualization)

        

if __name__ == '__main__':


    
    interfaz = Interface("COMMANDIA", (1200, 1500), [(240, 320), (240, 320), (240, 320), (240, 320)], "Close Interface", "Start program")
    
    interfaz.create_main_frame(BOTH, 1)
    interfaz.create_canvas(LEFT, BOTH, 1)
    interfaz.create_scrollbar(RIGHT, Y)
    interfaz.configure_canvas_for_scrollbar()
    interfaz.create_final_window((0,0), "nw")

    interfaz.exit_button()
    interfaz.start_button()
    interfaz.bc_button()

    interfaz.visualize_interface()
