#!/usr/bin/env python

# Software License Agreement (BSD License)
#
# Copyright (c) 2012, Robotiq, Inc.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following
#    disclaimer in the documentation and/or other materials provided
#    with the distribution.
#  * Neither the name of Robotiq, Inc. nor the names of its
#    contributors may be used to endorse or promote products derived
#    from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# Copyright (c) 2012, Robotiq, Inc.
# Revision $Id$

"""@package docstring
Command-line interface for sending simple commands to a ROS node controlling a 2F gripper.

This serves as an example for publishing messages on the 'Robotiq2FGripperRobotOutput' topic using the 'Robotiq2FGripper_robot_output' msg type for sending commands to a 2F gripper.
"""

import roslib; roslib.load_manifest('robotiq_2f_gripper_control')
import rospy
from std_msgs.msg import Float64
from robotiq_2f_gripper_control.msg import _Robotiq2FGripper_robot_output  as outputMsg
from time import sleep

pub = rospy.Publisher('Robotiq2FGripperRobotOutput', outputMsg.Robotiq2FGripper_robot_output,queue_size = 1000)

def processJointValue(valor_articular_gripper): 
 
    jointValue = outputMsg.Robotiq2FGripper_robot_output();

    print('Valor recibido ' + str(valor_articular_gripper))
    #print(jointValue)

    if valor_articular_gripper.data >= 0.0 and valor_articular_gripper.data <= 0.8: #valor articular dentro de los limites
	
        jointValue.rACT = 1
        jointValue.rGTO = 1
        jointValue.rSP  = 255
        jointValue.rFR  = 150
	
	#print("He sido yo.")
	#print(valor_articular_gripper.data)
	#print(jointValue)
        jointValue.rPR = int((valor_articular_gripper.data * 255)/0.8) #valor articular de entrada
        pub.publish(jointValue)
	#print("Salida: ")
	#print(jointValue)

    else:
        print('Error: valor articular fuera de los limites...')
   

def controlRobotiqGripper():

    rospy.init_node('robotiq_control')

    jointValue = outputMsg.Robotiq2FGripper_robot_output();
    jointValue.rACT = 1
    jointValue.rGTO = 1
    jointValue.rSP  = 255
    jointValue.rFR  = 150
    #jointValue.rPR  = 0

    #pub.publish(jointValue)

    print(jointValue)

    rospy.Subscriber("/valoresArticularesGripper", Float64, processJointValue)
    rospy.sleep(0.1)
    rospy.spin()
                      

if __name__ == '__main__':
    controlRobotiqGripper()

