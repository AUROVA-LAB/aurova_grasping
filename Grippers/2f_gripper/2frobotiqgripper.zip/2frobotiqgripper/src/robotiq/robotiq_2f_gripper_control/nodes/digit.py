#!/usr/bin/env python

import roslib
import rospy
import cv2

cap = cv2.VideoCapture(3)
cap2 = cv2.VideoCapture(4)


def publisher():
    """Main loop which requests new commands and publish them on the Robotiq2FGripperRobotOutput topic."""
    rospy.init_node('DIGIT')

    while cap.isOpened():
        ret, img = cap.read()
        ret, img2 = cap2.read()

	img =cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
        img2 =cv2.rotate(img2, cv2.ROTATE_90_COUNTERCLOCKWISE)

        cv2.imshow("window", img)
        cv2.imshow("window2", img2)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        
    


if __name__ == '__main__':
    publisher()
