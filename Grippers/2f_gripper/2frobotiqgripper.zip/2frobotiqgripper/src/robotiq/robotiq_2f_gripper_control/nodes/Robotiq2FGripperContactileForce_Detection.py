#!/usr/bin/env python

# Software License Agreement (BSD License)
#
# Copyright (c) 2012, Robotiq, Inc.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following
#    disclaimer in the documentation and/or other materials provided
#    with the distribution.
#  * Neither the name of Robotiq, Inc. nor the names of its
#    contributors may be used to endorse or promote products derived
#    from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# Copyright (c) 2012, Robotiq, Inc.
# Revision $Id$

"""@package docstring
Command-line interface for sending simple commands to a ROS node controlling a 2F gripper.

This serves as an example for publishing messages on the 'Robotiq2FGripperRobotOutput' topic using the 'Robotiq2FGripper_robot_output' msg type for sending commands to a 2F gripper.
"""

import roslib; roslib.load_manifest('robotiq_2f_gripper_control') 
import rospy
from robotiq_2f_gripper_control.msg import _Robotiq2FGripper_robot_output  as outputMsg
from robotiq_2f_gripper_control.msg import _Robotiq2FGripper_robot_input  as inputMsg
from papillarray_ros_v2.msg import SensorState
from time import sleep

class Gripping:
    def __init__(self):
        self.msg0 = 0
        #self.msg1 = 0
        self.rPR = 0
        self.done = 0
        self.grippermax = 0

    def genCommand(self, Pvalue, command):
        #If the command entered is a int, assign this value to rPRA
        command.rACT = 1
        command.rGTO = 1
        command.rSP = 0
        command.rFR = 0
        try: 
            command.rPR = int(Pvalue)
            if command.rPR > 255:
                command.rPR = 255
            if command.rPR < 0:
                command.rPR = 0
        except ValueError:
            pass                    
        return command
    
    def commandStop(self, rGTO, command):
        command.rGTO = rGTO
        return command
        
        

    def publisher(self):
        """Main loop which requests new commands and publish them on the Robotiq2FGripperRobotOutput topic."""
        #rospy.init_node('Robotiq2FGripperContactileForce_Detection')
    
        self.pub = rospy.Publisher('Robotiq2FGripperRobotOutput', outputMsg.Robotiq2FGripper_robot_output, queue_size = 1)

        self.listener()

        command = outputMsg.Robotiq2FGripper_robot_output();

        threshold = input('\nDesired gripping force? (N)\n')
        print(threshold)

        #command = self.genCommand(self.grippermax, command)

        #print('Moving to position', self.grippermax)          
        
        #self.pub.publish(command)

        while self.done != 1:

            #Pvalue = self.autoclose(threshold)
            command = self.genCommand(self.rPR, command)  
            #print('Moving to position', self.rPR)       
            print("Desired force: ", threshold)
            rGTO = self.autoclose(threshold)
            command = self.commandStop(rGTO, command)   
        
            self.pub.publish(command)

            #rospy.sleep(0.1)
        
        

    def listener(self):
        """Node getting force information from the 2 Contactile sensors"""
        self.sensor0 = rospy.Subscriber('/hub_0/sensor_0', SensorState, self.callback0, queue_size = 1)
        #self.sensor1 = rospy.Subscriber('/hub_0/sensor_1', SensorState, self.callback1, queue_size = 1)
        self.gripperstate = rospy.Subscriber('/Robotiq2FGripperRobotInput', inputMsg.Robotiq2FGripper_robot_input, self.callbackG, queue_size = 1)

    def callback0(self, data):
        """Gripping force is the global force along the Z axis"""
        self.msg0 = data.gfZ
        

    #def callback1(self, data):
    #    """Gripping force is the global force along the Z axis"""
    #    self.msg1 = data.gfZ

    def callbackG(self, data):
        """Position of the gripper in real time"""
        self.currentposition = data.gPO
        

    def autoclose(self, threshold):     # Target force value in newtons
        """Tell gripper to fully close, then stop it when both sensors go above the force threshold"""
        print("Actual force: ", self.msg0)
        #print(self.msg1)
        print("Actual position: ", self.currentposition)
        
        #if (self.msg0 > threshold or self.msg1 > threshold):
        if self.msg0 >= threshold:
            #self.rPR = self.currentposition 
            self.rGTO = 0
            self.done = 1
            
            """ else:
            self.rPR = self.grippermax """
        else:
            self.rGTO = 1
            self.rPR = self.currentposition + 1
            
        return self.rGTO
        #return self.rPR
                        

def launch():
    grip = Gripping()
    grip.publisher()

if __name__ == '__main__':
    grip = Gripping()
    grip.publisher()
