#!/usr/bin/env python

# Software License Agreement (BSD License)
#
# Copyright (c) 2012, Robotiq, Inc.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following
#    disclaimer in the documentation and/or other materials provided
#    with the distribution.
#  * Neither the name of Robotiq, Inc. nor the names of its
#    contributors may be used to endorse or promote products derived
#    from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# Copyright (c) 2012, Robotiq, Inc.
# Revision $Id$

"""@package docstring
Command-line interface for sending simple commands to a ROS node controlling a 2F gripper.

This serves as an example for publishing messages on the 'Robotiq2FGripperRobotOutput' topic using the 'Robotiq2FGripper_robot_output' msg type for sending commands to a 2F gripper.
"""

import roslib; roslib.load_manifest('robotiq_2f_gripper_control')
import rospy
from robotiq_2f_gripper_control.msg import _Robotiq2FGripper_robot_output  as outputMsg
from robotiq_2f_gripper_control.msg import _Robotiq2FGripper_robot_input  as inputMsg
import time
import zmq 
import cv2

# current position of the fingers of the gripper
current_position = 0
# max number of contact detections
MAX_CONTACT_DET = 2
# max number of no contact detections
MAX_NCONTACT_DET = 5
# callback mode variable
mode = "grasping"
# actual number of contact detections
contact_det_count = 0
# actual number of no contact detection
ncontact_det_count = 0


def close_gripper(value):

    """
    Closes the gripper from current_position to current_position + value

    -Arguments:
        -value: Int that represents the value we want to close from current_position.
    
    -Returns: An object representing the msg of the topic called Robotiq2FGripperOutput
    """

    # current_position has to be a global variable
    global current_position

    # reading output values to extract current position
    command = outputMsg.Robotiq2FGripper_robot_output()
    command.rACT = 1
    command.rGTO = 1
    command.rSP  = 0
    command.rFR  = 0
    # add the value to close the gripper
    if current_position + value <= 255:
        command.rPR = current_position + value
    else:
        command.rPR = 255
    #command.rPR = current_position + value
    # print(command.rPR)

    return command


def open_gripper(value):

    """
    Opens the gripper from current_position to current_position - value

    -Arguments:
        -value: Int that represents the value we want to open from current_position.
    
    -Returns: An object representing the msg of the topic called Robotiq2FGripperOutput
    """

    global current_position

    command = outputMsg.Robotiq2FGripper_robot_output()
    command.rACT = 1
    command.rGTO = 1
    command.rSP  = 0
    command.rFR  = 0
    # substract the value to open the gripper
    if current_position - value >= 0:
        command.rPR = current_position - value
    else:
        command.rPR = 0
    #command.rPR = current_position - value

    return command


def callback(msg):

    """
        Reads current position from requested output position. It's important to read
    the requested and not the current because the current is obtained from the encoders,
    and is not always the same as the requested.

        -Arguments:
            -msg: Ros msg of Robotiq2FGripperRobotInput topic.
        
    """

    global current_position
    current_position = msg.gPR
    #print(current_position)


def slip_mode(data, pub):

    if data == 0:
        print("STABLE")
    elif data == 1:
        print("UNSTABLE")
        command = close_gripper(5)
        pub.publish(command)
        rospy.sleep(0.1)
    

def grasping_mode(data, pub):
    global mode, contact_det_count

    #no contact detection
    if data == 0:
        print("Closing until contact...")
        command = close_gripper(1)
        pub.publish(command)
        rospy.sleep(0.1)
    elif data == 1:
        
        contact_det_count += 1
        print("Detected contact: {}!".format(str(contact_det_count)))
        if contact_det_count < MAX_CONTACT_DET:
            command = close_gripper(1)
            pub.publish(command)
            rospy.sleep(0.1)
        elif contact_det_count == MAX_CONTACT_DET:
            print("changing operation mode to slip detection!")
            mode = "hold"
    

def releasing_mode(data, pub):
    global mode, ncontact_det_count

    if data == 1:  # openinig while contact is detected
        print("Opening gripper...")
        command = open_gripper(255)
        pub.publish(command)
        rospy.sleep(1)

    elif data == 0:
        ncontact_det_count += 1
        print("Detected no contact: {}!".format(str(ncontact_det_count)))
        if ncontact_det_count == MAX_NCONTACT_DET:
            mode = "finish"




def main():
    # use log_leve = rospy.DEBUG for debugging.
    # rospy.init_node("comm_test", log_level=rospy.DEBUG)
    rospy.init_node('Robotiq2FGripperSimpleControllerCommandia')
    
    pub = rospy.Publisher('Robotiq2FGripperRobotOutput', outputMsg.Robotiq2FGripper_robot_output)

    sub = rospy.Subscriber('Robotiq2FGripperRobotInput', inputMsg.Robotiq2FGripper_robot_input, callback)

    rospy.loginfo("HEY! I'M USING ROS!")

    PORT = "5556"

    context = zmq.Context()
    client = context.socket(zmq.REQ)

    client.connect("tcp://localhost:%s" % PORT)
    data = 0
    

    # switch modes
    operation_mode = {0: "grasping", 1: "hold", 2: "release", 3: "finish"}
    global mode
    i = 0

    while True:

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        
        if mode == "grasping":
            send = 0
        elif mode == "hold":
            send = 1
        elif mode == "release":
            send = 0
        else:
            print("Finish!")
            client.send_pyobj(9)
            break
        
        client.send_pyobj(send)    
        data = client.recv_pyobj()

        if mode == operation_mode.get(0):
            print("Grasping the object...")
            grasping_mode(data, pub)
        
        elif mode == operation_mode.get(1):
            print("Holding the object...")
            if i == 0:
                a = time.time()
                i+=1
                
            slip_mode(data, pub)
            b = time.time()
            if b-a >= 5:
                mode = "release"

        elif mode == operation_mode.get(2):
            print("Releasing the object...")
            releasing_mode(data, pub)
        
        elif mode == operation_mode.get(3):
            break

        else:
            break

    client.close()
    context.term()
    


if __name__ == '__main__':
    main()
