#!/usr/bin/env python

import rospy
from std_msgs.msg import *
from papillarray_ros_v2.msg import SensorState
import time

import tkinter_interface as tki
import tkinter_refresh as tkr

'''
This program is no longer needed, run tkinter_interface_v2.py instead
'''

### ROS listener node

def callback_0(data):
    None # Remplacer comme dans callback_1 quand termine
    #rospy.loginfo(rospy.get_caller_id() + '\n sensor_0 \n %s', data)

def callback_1(data):
    #rospy.loginfo(rospy.get_caller_id() + '\n sensor_1 \n %s', data)
    #msg = data.pillars[1].fX # Force along X axis for pillar number 1
    msg = [data.pillars[i].fZ for i in range(9)]
    #tki.interface(msg)
    

    #return msg

def listener():

    rospy.init_node('combined_collector', anonymous=False)

    #rospy.Subscriber('/hub_0/sensor_0', SensorState, callback_0)

    rospy.Subscriber('/hub_0/sensor_1', SensorState, callback_1)

    rospy.spin()

    # is sensor 0 pillar 1 data given by: s0p1 = rospy.Subscriber('/hub_0/sensor_0', SensorState, callback_0)[1] ???

if __name__ == '__main__':
    #tki.interface([0,0,0,0,0,0,0,0,0])
    listener()
