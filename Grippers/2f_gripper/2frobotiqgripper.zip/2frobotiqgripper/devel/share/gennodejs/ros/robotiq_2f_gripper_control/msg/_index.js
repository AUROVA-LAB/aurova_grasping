
"use strict";

let Robotiq2FGripper_robot_input = require('./Robotiq2FGripper_robot_input.js');
let Robotiq2FGripper_robot_output = require('./Robotiq2FGripper_robot_output.js');

module.exports = {
  Robotiq2FGripper_robot_input: Robotiq2FGripper_robot_input,
  Robotiq2FGripper_robot_output: Robotiq2FGripper_robot_output,
};
