
"use strict";

let sensor_accessor = require('./sensor_accessor.js')

module.exports = {
  sensor_accessor: sensor_accessor,
};
