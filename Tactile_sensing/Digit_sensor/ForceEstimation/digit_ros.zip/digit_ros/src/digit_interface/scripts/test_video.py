import cv2


video = cv2.VideoCapture("/home/aurova/Desktop/julio/tactile_vision2force/digit_ros/src/digit_interface/scripts/sensor45_taza_roja_papilarray.mp4")


while video.isOpened():

    ret, frame = video.read()
    cv2.imshow("img", frame)
    cv2.waitKey(100)

video.release()
