#!/home/aurova/anaconda3/envs/digit_depth/bin/python3


import rospy
from sensor_msgs.msg import Image, CompressedImage
import message_filters
from papillarray_ros_v2.msg import SensorState

import cv2
import numpy as np
import os
import matplotlib.pyplot as plt
import time


digit_image = None
gt_force = None
realsense_image = None

t1 = None
t2 = None

fourcc = cv2.VideoWriter_fourcc('M','J','P','G')
out = cv2.VideoWriter('/home/aurova/Desktop/julio/tactile_vision2force/digit_ros/src/digit_interface/scripts/output.avi', fourcc, 30.0, (640,480))


def create_video():
	
	global digit_image, gt_force, realsense_image

	idx_cont = 0
			
	while not rospy.is_shutdown():

		if digit_image is not None and realsense_image is not None:
		#if digit_image is not None and gt_force > 0.75 and gt_force <= 15 and realsense_image is not None and idx_cont < len(papilarray_video):

			sensor_frame = digit_image
			camera_frame = realsense_image

			digit_h, digit_w, _ = sensor_frame.shape

			h_c = digit_h//2
			w_c = digit_w//2

			resized_sensor_frame = cv2.resize(sensor_frame, (120,160), interpolation = cv2.INTER_AREA)
			
			camera_frame[200 : 200+h_c, 500 : 500+w_c] = resized_sensor_frame

			cv2.imshow("img", camera_frame)
			cv2.waitKey(35)
			out.write(camera_frame)

	out.release()



def callback(img, force, cam_img):
	
	global digit_image, gt_force, realsense_image
	
	np_arr = np.frombuffer(cam_img.data, np.uint8)
	realsense_image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
	
	np_arr = np.frombuffer(img.data, np.uint8)
	digit_image = np.reshape(np_arr, (320,240,3))

	gt_force = force.gfZ


	

def main():

	rospy.init_node('force_estimation', anonymous=True)

	digit_img_sub = message_filters.Subscriber("digit55/camera/image_color", Image)
	contactile_force_sub = message_filters.Subscriber('/hub_0/sensor_0', SensorState)
	realsense_camera_sub = message_filters.Subscriber('/camera/color/image_raw/compressed', CompressedImage)
	
	ts = message_filters.ApproximateTimeSynchronizer([digit_img_sub, contactile_force_sub, realsense_camera_sub], queue_size=15, slop=0.1)
	ts.registerCallback(callback)

	create_video()
	
	


if __name__ == "__main__":
	rospy.loginfo("starting...")
	main()
