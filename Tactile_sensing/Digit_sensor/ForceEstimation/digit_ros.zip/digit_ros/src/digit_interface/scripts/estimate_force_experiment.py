#!/home/aurova/anaconda3/envs/digit_depth/bin/python3


from unicodedata import digit
import rospy
from sensor_msgs.msg import Image
import message_filters
from papillarray_ros_v2.msg import SensorState

import cv2
#import ros_numpy
import numpy as np
import os
import matplotlib.pyplot as plt
import time

import torch
import torch.nn as nn
import torchvision.transforms as T

import sys
sys.path.append("/home/aurova/Desktop/julio/tactile_vision2force/code_deeplearning/")

from utils import get_test_loader, load_checkpoint
from models import Resnet_modified


DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
BATCH_SIZE = 1
NUM_WORKERS = os.cpu_count()
PIN_MEMORY = True

digit_image = None
gt_force = None

t1 = None
t2 = None

t1_inference = None
t2_inference = None


def publish_force_value(model, test_transform):
	'''
	Publish the estimated force value in N from the RGB image.
	'''
	
	global digit_image, gt_force

	pred_forces = []
	gt_forces = []

	t1 = time.time()
	time_list = []

	while not rospy.is_shutdown():

		#if digit_image is not None:
		if digit_image is not None and gt_force > 0.75 and gt_force <= 15:

			frame = digit_image
			frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

			t1_inference = time.time()

			preprocess_img = test_transform(frame_rgb)

			preprocess_img_cuda = preprocess_img.unsqueeze(0).to(DEVICE)
			predicted_force = model(preprocess_img_cuda) 
			print(predicted_force)

			t2_inference = time.time()

			print(t2_inference-t1_inference)

			pred_forces.append(predicted_force.detach().cpu().numpy().squeeze())
			print(gt_force)
			gt_forces.append(gt_force)
			
			t2 = time.time()
			time_list.append(t2-t1)


	pred_forces_np = np.asarray(pred_forces)
	gt_forces_np = np.asarray(gt_forces)
	error = np.mean(np.abs(pred_forces_np-gt_forces_np))
	std = np.std(np.abs(pred_forces_np-gt_forces_np))
	print(f"Error = {error} +- {std}")

	new_time_list = time_list - np.min(time_list)

	# interval 0.5-1-5
	int_time_list = []
	int_pred_forces = []
	int_gt_forces = []
	for idx in range(len(new_time_list)):
		if new_time_list[idx] >= 0.5 and new_time_list[idx] <= 1.5:
			int_time_list.append(new_time_list[idx])
			int_pred_forces.append(pred_forces_np[idx])
			int_gt_forces.append(gt_forces_np[idx])

	# print means 
	print(f"Error in 0.5-1-5 interval: {abs(np.mean(int_pred_forces) - np.mean(int_gt_forces))}")

	'''
	plt.rcParams.update({'font.size': 16})

	plt.plot(new_time_list, pred_forces, label="pred_force")
	plt.plot(new_time_list, gt_forces, label="gt_force")
	plt.xlabel("Time (s)")
	plt.ylabel("MAE (N)")
	plt.legend(loc='lower center')
	plt.show()
	
	print(pred_forces_np.shape, gt_forces_np.shape, len(new_time_list))
	'''
	#np.save("/home/aurova/Desktop/julio/tactile_vision2force/digit_ros/src/digit_interface/scripts/pred_forces.npy", pred_forces_np)
	#np.save("/home/aurova/Desktop/julio/tactile_vision2force/digit_ros/src/digit_interface/scripts/gt_forces.npy", gt_forces_np)
	#np.save("/home/aurova/Desktop/julio/tactile_vision2force/digit_ros/src/digit_interface/scripts/time.npy", new_time_list)


def callback(img, force):
	
	global digit_image, gt_force

	
	np_arr = np.frombuffer(img.data, np.uint8)
	digit_image = np.reshape(np_arr, (320,240,3))

	gt_force = force.gfZ


	

def main():

	rospy.init_node('force_estimation', anonymous=True)

	digit_img_sub = message_filters.Subscriber("digit55/camera/image_color", Image)
	contactile_force_sub = message_filters.Subscriber('/hub_0/sensor_0', SensorState)

	ts = message_filters.ApproximateTimeSynchronizer([digit_img_sub, contactile_force_sub], queue_size=15, slop=0.1)
	ts.registerCallback(callback)

	load_path = "/home/aurova/Desktop/julio/tactile_vision2force/code_deeplearning/weights/training23/checkpoint_epoch_24.pth.tar"

	model = Resnet_modified().to(DEVICE)

	load_checkpoint(torch.load(os.path.join(load_path)), model)

	model.eval()

	test_transform = T.Compose(
		[
		T.ToTensor(),
		T.Normalize(
			mean=[0.0, 0.0, 0.0],
			std=[1.0, 1.0, 1.0],
		),
		],
	)

	publish_force_value(model, test_transform)
	
	


if __name__ == "__main__":
	rospy.loginfo("starting...")
	main()
