#!/home/aurova/anaconda3/envs/digit_depth/bin/python3


import rospy
from sensor_msgs.msg import Image
from std_msgs.msg import Float32
import message_filters
from papillarray_ros_v2.msg import SensorState

import cv2
import ros_numpy
import os
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torchvision.transforms as T

import sys
sys.path.append("/home/aurova/Desktop/julio/tactile_vision2force/code_deeplearning/")

from utils import get_test_loader, load_checkpoint
from models import Resnet_modified


DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
BATCH_SIZE = 1
NUM_WORKERS = os.cpu_count()
PIN_MEMORY = True

digit_image = None
gt_force = None


def publish_force_value(model, test_transform, pub_force):
	'''
	Publish the estimated force value in N from the RGB image.
	'''
	
	global digit_image, gt_force

	while not rospy.is_shutdown():

		if digit_image is not None and gt_force <= 15:

			frame = digit_image
			frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

			preprocess_img = test_transform(frame_rgb)

			preprocess_img_cuda = preprocess_img.unsqueeze(0).to(DEVICE)
			predicted_force = model(preprocess_img_cuda) 

			post_pred_force = predicted_force.detach().cpu().numpy().squeeze()
			
			pub_force.publish(post_pred_force)

	




def callback(img, force):
	
	global digit_image, gt_force

	digit_image = ros_numpy.numpify(img)

	gt_force = force.gfZ


	

def main():

	rospy.init_node('force_estimation', anonymous=True)

	digit_img_sub = message_filters.Subscriber("digit55/camera/image_color", Image)
	contactile_force_sub = message_filters.Subscriber('/hub_0/sensor_0', SensorState)

	pub_force = rospy.Publisher(f"digit/force_value", Float32, queue_size=10)

	ts = message_filters.ApproximateTimeSynchronizer([digit_img_sub, contactile_force_sub], queue_size=15, slop=0.1)
	ts.registerCallback(callback)

	load_path = "/home/aurova/Desktop/julio/tactile_vision2force/code_deeplearning/weights/training23/checkpoint_epoch_24.pth.tar"

	model = Resnet_modified().to(DEVICE)

	load_checkpoint(torch.load(os.path.join(load_path)), model)

	model.eval()

	test_transform = T.Compose(
		[
		T.ToTensor(),
		T.Normalize(
			mean=[0.0, 0.0, 0.0],
			std=[1.0, 1.0, 1.0],
		),
		],
	)

	publish_force_value(model, test_transform, pub_force)
	
	


if __name__ == "__main__":
	rospy.loginfo("starting...")
	main()
