#!/home/aurova/anaconda3/envs/digit_depth/bin/python3

"""
    By default, depth image measures the distance from the camera to the gel surface in meters.
    When the gel is not deformed, the depth value is max depth.When the gel is deformed, this value gets smaller.
    This node publishes the difference betweeb min depth (max deformation) and background depth value(min deformation)
    Note that we multiply by 1000 to convert from meters to millimeters.
"""
import rospy
from std_msgs.msg import Float32
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

import sys
sys.path.append("/home/aurova/Desktop/julio/tactile_vision2force/digit-depth/")

from digit_depth.third_party import geom_utils
from digit_depth.digit.digit_sensor import DigitSensor
from digit_depth.train.prepost_mlp import *
from digit_depth.handlers import find_recent_model
from digit_depth.third_party import vis_utils
from digit_depth.handlers import find_recent_model, find_background_img
from attrdict import AttrDict

import cv2
import open3d as o3d

from omegaconf import OmegaConf


import ros_numpy


seed = 42
torch.seed = seed
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

base_path = "/home/aurova/Desktop/julio/tactile_vision2force/digit_ros/src/digit_interface"


GEL_WIDTH = 0.01832
GEL_HEIGHT = 0.02505
MAX_DEPTH = 0.02076
FPS = 30
RESOLUTION = "QVGA"
SERIAL_NUM = "D00055"

SENSOR_PROJ_MATRIX =  [ [ 2.30940108e+00, 0.00000000e+00, 0.00000000e+00, 0.00000000e+00 ],
         [ 0.00000000e+00, 1.73205081e+00, 0.00000000e+00, 0.00000000e+00 ],
         [ 0.00000000e+00, 0.00000000e+00, -1.04081633e+00, -2.04081633e-03 ],
         [ 0.00000000e+00, 0.00000000e+00, -1.00000000e+00, 0.00000000e+00 ] ]

Z_NEAR = 0.001
Z_FAR = 0.05

SENSOR = OmegaConf.create({'gel_width':GEL_WIDTH, 'gel_height':GEL_HEIGHT, 'max_depth':MAX_DEPTH, 'fps':FPS,
                           'resolution':RESOLUTION, "serial_num":SERIAL_NUM, "sensor_proj_matrix":SENSOR_PROJ_MATRIX, 'z_near':Z_NEAR, 'z_far':Z_FAR})

digit_image = None
cvbridge = CvBridge()


def get_depth_values(model, img_np):
    """
    Calculate the depth values for an image using the given model.

    Parameters:
    - model: PyTorch model for calculating depth values
    - img_np: NumPy array representing the image

    Returns:
    - img_depth: NumPy array of depth values for the image
    """
    img_np = preproc_mlp(img_np)
    img_np = model(img_np).detach().cpu().numpy()
    img_np, _ = post_proc_mlp(img_np)

    gradx_img, grady_img = geom_utils._normal_to_grad_depth(
        img_normal=img_np, gel_width=GEL_WIDTH,
        gel_height=GEL_HEIGHT, bg_mask=None
    )
    img_depth = geom_utils._integrate_grad_depth(
        gradx_img, grady_img, boundary=None, bg_mask=None, max_depth=MAX_DEPTH
    )
    img_depth = img_depth.detach().cpu().numpy().flatten()
    return img_depth


def publish_depth_difference(model, pub):
    '''
    Publish the difference between the maximum and minimum depth values
    for an image.
    '''

    global digit_image

    dp_zero = 0
    dp_zero_counter = 0

    while not rospy.is_shutdown():
        #frame = digit_call.get_frame()
        frame = digit_image
        if frame is None:
            continue

        # dp_zero is the "background" depth value.
        if dp_zero_counter < 100:
            img_depth = get_depth_values(model, frame)
            dp_zero += np.min(img_depth)
            dp_zero_counter += 1
            continue
        elif dp_zero_counter == 100:
            dp_zero = dp_zero / 100
            dp_zero_counter += 1

        img_depth = get_depth_values(model, frame)
        max_deformation = np.min(img_depth)
        print(f"Max deformation : {max_deformation}")
        actual_deformation = np.abs((max_deformation - dp_zero))
        pub.publish(Float32(actual_deformation * 1000))  # convert to mm
        rospy.loginfo(f"Published msg at {rospy.get_time()}")


def publish_point_cloud(model, pub, view_params):
    '''
    Publish the 3D reconstructed point cloud from the RGB image.
    '''
    
    global digit_image

    vis3d = vis_utils.Visualizer3d(base_path=base_path, view_params=view_params)

    # projection params
    proj_mat = torch.tensor(SENSOR_PROJ_MATRIX)
    model_path = find_recent_model(f"{base_path}/models")
    model = torch.load(model_path).to(device)
    model.eval()
    # base image depth map
    background_img_path = find_background_img(base_path)
    background_img = cv2.imread(background_img_path)
    background_img = preproc_mlp(background_img)
    background_img_proc = model(background_img).cpu().detach().numpy()
    background_img_proc, _ = post_proc_mlp(background_img_proc)
    # get gradx and grady
    gradx_base, grady_base = geom_utils._normal_to_grad_depth(img_normal=background_img_proc, gel_width=GEL_WIDTH,
                                                              gel_height=GEL_HEIGHT, bg_mask=None)

    # reconstruct depth
    img_depth_base = geom_utils._integrate_grad_depth(gradx_base, grady_base, boundary=None, bg_mask=None,
                                                      max_depth=0.0237)
    img_depth_base = img_depth_base.detach().cpu().numpy() # final depth image for base image


    while True:

        frame = digit_image

        if frame is not None:
            
            img_np = preproc_mlp(frame)
            img_np = model(img_np).detach().cpu().numpy()
            img_np, _ = post_proc_mlp(img_np)
            # get gradx and grady
            gradx_img, grady_img = geom_utils._normal_to_grad_depth(img_normal=img_np, gel_width=GEL_WIDTH,
                                                                    gel_height=GEL_HEIGHT,bg_mask=None)
            # reconstruct depth
            img_depth = geom_utils._integrate_grad_depth(gradx_img, grady_img, boundary=None, bg_mask=None, max_depth=MAX_DEPTH)
            view_mat = torch.eye(4)  # torch.inverse(T_cam_offset)
            # Project depth to 3D
            points3d = geom_utils.depth_to_pts3d(depth=img_depth, P=proj_mat, V=view_mat, params=SENSOR)
            points3d = geom_utils.remove_background_pts(points3d, bg_mask=None)
            cloud = o3d.geometry.PointCloud()
            clouds = geom_utils.init_points_to_clouds(clouds=[copy.deepcopy(cloud)], points3d=[points3d])
            print(clouds)
            vis_utils.visualize_geometries_o3d(vis3d=vis3d, clouds=clouds)



def callback(data):
    
    global digit_image
    digit_image = ros_numpy.numpify(data)
    



def main():

    model_path = find_recent_model(f"{base_path}/models")
    model = torch.load(model_path).to(device)
    model.eval()

    #pub = rospy.Publisher('digit/depth/value', Float32, queue_size=1)
    pub = rospy.Publisher('digit/depth/point_cloud', Float32, queue_size=1)
    sub = rospy.Subscriber("digit55/camera/image_color", Image, callback)
    rospy.init_node('depth', anonymous=True)
    
    #publish_depth_difference(model, pub)

    view_params = AttrDict({
                "fov": 60,
                "front": [-0.3, 0.0, 0.5],
                "lookat": [-0.001, 0.001,-0.001],
                "up": [0.0, 0.0, 0.50],
                "zoom": 0.5,
            })

    publish_point_cloud(model, pub, view_params)


if __name__ == "__main__":
    rospy.loginfo("starting...")
    main()
